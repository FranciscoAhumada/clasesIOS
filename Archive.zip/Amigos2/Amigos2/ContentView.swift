//
//  ContentView.swift
//  Amigos2
//
//  Created by user162332 on 1/24/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Formuario()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
