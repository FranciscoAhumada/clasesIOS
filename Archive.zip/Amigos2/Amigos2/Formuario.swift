//
//  Formuario.swift
//  Amigos2
//
//  Created by user162332 on 1/24/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import SwiftUI

struct Formuario: View {
    
    @State private var nombre: String = ""
    @State private var rut: String = ""
    @State private var isPremium: Bool = false
    
    var body: some View {
        Form{
            VStack{
                Text("Nombre")
                TextField("Nombre", text: $nombre)
                Text("Rut")
                TextField("Rut",text: $rut)
                Toggle(isOn: $isPremium) {
                    Text("es premium")
                }
            }
        }
    }
}

struct Formuario_Previews: PreviewProvider {
    static var previews: some View {
        Formuario()
    }
}
