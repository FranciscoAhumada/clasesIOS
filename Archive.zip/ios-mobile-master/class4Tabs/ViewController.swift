//
//  ViewController.swift
//  class4Tabs
//
//  Created by user164457 on 1/16/20.
//  Copyright © 2020 user164457. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
