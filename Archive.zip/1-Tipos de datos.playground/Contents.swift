import UIKit

//Tipos de datos


//declaracion de datos

//constantes let//
let nombre = "marco"
let edad = 32
let localizacion = 3423.232323
let log = true


//Variables var//

var nombre2 = "marco"
var edad2 = 32
var localizacion2 = 3423.232323
var log2 = true

print(nombre2)

nombre2 = "paco"
print(nombre2)

var opcional : Int?
var obligatoria : Int!

class persona {
    let ID = UUID()
    var nombre : String!
    var edad : Int!
    
    init(nombre : String, edad : Int){
        self.nombre = nombre
        self.edad = edad
    }
    
    func calcular(numero: Int){
        self.edad * numero
    }
    
    func calcularRetorno(numero: Int) -> Int{
        return self.edad * numero
    }
    
    func calaf(numero:Int, completion:@escaping(Int)->Void){
        let valor = self.edad * numero
        completion(valor)
    }
    
    func salidas(escala:Int){
        
    }
}


