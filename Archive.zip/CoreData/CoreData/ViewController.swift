//
//  ViewController.swift
//  CoreData
//
//  Created by user162332 on 1/21/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        let add = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(formView))
        
        self.navigationItem.rightBarButtonItem = add
    }


}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "personCell", for: indexPath)
        return cell
    }
}

extension ViewController{
    
    @objc func formView(){
        DispatchQueue.main.async {
            self.performSegue(withIdentifier: "form", sender: self)
        }
    }
    
    @IBAction func homeVC(segue:UIStoryboardSegue){
        
    }
    
    @objc func addNewPerson(){
        
        let form = UIAlertController(title: "Registro de Persona", message: "complete todos los campos para continuar", preferredStyle: .alert)
        
        form.addTextField { (textField) in
            textField.placeholder = "Nombre"
            textField.keyboardAppearance = .dark
            textField.keyboardType = .default
            textField.autocorrectionType = .yes
            textField.autocapitalizationType = .words
        }
        
        form.addTextField { (textField) in
            textField.placeholder = "Rut"
            textField.keyboardAppearance = .dark
            textField.keyboardType = .default
            textField.autocorrectionType = .yes
            textField.autocapitalizationType = .words
        }
        
        form.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        form.addAction(UIAlertAction(title: "Guardar", style: .default, handler: { (action) in
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            let 👤 = NSManagedObject(entity: NSEntityDescription.entity(forEntityName: "Persona", in: context)!, insertInto: context)
            
            👤.setValue(form.textFields![0].text, forKey: "nombre")
            👤.setValue(form.textFields![1].text, forKey: "rut")
            
            do{
                try context.save()
                print("guardo")
            }catch let errorSave as NSError{
                print("No guardo", errorSave)
            }
            
        }))
        
        self.present(form, animated: true, completion: nil)
        
    }
    
}
