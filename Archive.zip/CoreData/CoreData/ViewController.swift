//
//  ViewController.swift
//  CoreData
//
//  Created by user162332 on 1/21/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    var 👥 : [Persona] = []
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        let add = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(formView))
        
        self.navigationItem.rightBarButtonItem = add
        
        self.loadDataBase()
    }


}

extension ViewController: NSFetchedResultsControllerDelegate{
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.beginUpdates()
    }
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            self.tableView.insertRows(at:[newIndexPath!], with: .automatic)
        case .delete:
            self.tableView.deleteRows(at: [indexPath!], with: .automatic)
        case .move:
            self.tableView.moveRow(at: indexPath!, to: newIndexPath!)
        case .update:
            self.tableView.reloadRows(at: [indexPath!], with: .automatic)
        @unknown default:
            break
        }
        
        self.👥 = controller.fetchedObjects as! [Persona]
    }
    
    func  controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.endUpdates()
    }
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.👥.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "personCell", for: indexPath)
        
        cell.textLabel?.text = self.👥[indexPath.row].nombre
        cell.detailTextLabel?.text = self.👥[indexPath.row].rut
        return cell
    }
}

extension ViewController{
    
    @objc func formView(){
        DispatchQueue.main.async {
            self.performSegue(withIdentifier: "form", sender: self)
        }
    }
    
    func loadDataBase(){
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let fetch: NSFetchRequest<Persona> = Persona.fetchRequest()
        fetch.sortDescriptors = [NSSortDescriptor(key: "nombre", ascending: true)]
        
        let fetchResultControler = NSFetchedResultsController(fetchRequest: fetch, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
        fetchResultControler.delegate = self
        do{
            try fetchResultControler.performFetch()
            self.👥 = fetchResultControler.fetchedObjects!
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }catch let error as NSError{
            print("error ", error)
        }
    }
    
    @IBAction func homeVC(segue:UIStoryboardSegue){
        
    }
    
    @objc func addNewPerson(){
        
        let form = UIAlertController(title: "Registro de Persona", message: "complete todos los campos para continuar", preferredStyle: .alert)
        
        form.addTextField { (textField) in
            textField.placeholder = "Nombre"
            textField.keyboardAppearance = .dark
            textField.keyboardType = .default
            textField.autocorrectionType = .yes
            textField.autocapitalizationType = .words
        }
        
        form.addTextField { (textField) in
            textField.placeholder = "Rut"
            textField.keyboardAppearance = .dark
            textField.keyboardType = .default
            textField.autocorrectionType = .yes
            textField.autocapitalizationType = .words
        }
        
        form.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        form.addAction(UIAlertAction(title: "Guardar", style: .default, handler: { (action) in
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            let 👤 = NSManagedObject(entity: NSEntityDescription.entity(forEntityName: "Persona", in: context)!, insertInto: context)
            
            👤.setValue(form.textFields![0].text, forKey: "nombre")
            👤.setValue(form.textFields![1].text, forKey: "rut")
            
            do{
                try context.save()
                print("guardo")
            }catch let errorSave as NSError{
                print("No guardo", errorSave)
            }
            
        }))
        
        self.present(form, animated: true, completion: nil)
        
    }
    
}
