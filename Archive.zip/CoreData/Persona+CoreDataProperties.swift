//
//  Persona+CoreDataProperties.swift
//  CoreData
//
//  Created by user162332 on 1/22/20.
//  Copyright © 2020 Prueba. All rights reserved.
//
//

import Foundation
import CoreData


extension Persona {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Persona> {
        return NSFetchRequest<Persona>(entityName: "Persona")
    }

    @NSManaged public var imagenUsuario: Data?
    @NSManaged public var nombre: String?
    @NSManaged public var rut: String?

}
