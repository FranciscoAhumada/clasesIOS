//
//  Tarjeta+CoreDataProperties.swift
//  CoreData
//
//  Created by user162332 on 1/22/20.
//  Copyright © 2020 Prueba. All rights reserved.
//
//

import Foundation
import CoreData


extension Tarjeta {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Tarjeta> {
        return NSFetchRequest<Tarjeta>(entityName: "Tarjeta")
    }

    @NSManaged public var cvc: String?
    @NSManaged public var fechaVencimineto: Date?
    @NSManaged public var numeroTarjeta: Int64
    @NSManaged public var tipoTarjeta: String?

}
