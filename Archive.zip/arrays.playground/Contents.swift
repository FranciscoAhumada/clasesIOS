import Foundation

var ciudades : [String] = ["valpo","talca","quillota"]
var valores : [String: AnyObject] = ["sol":"estrella" as AnyObject, "rut": 169874583 as AnyObject]


for i in ciudades{
    print(i)
}

for i in ciudades.enumerated(){
    print(i)
}

ciudades.contains("quillota")

for (_,v) in valores{
    print(v)
}

for (key ,v) in valores{
    print(key,v)
}

var tupla = ("lugares",213,true,3.34)

print(tupla)

func user (value:(String,Int,Bool,Double)){
    print(value)
}

user(value:tupla)

var 🙃 = "Prueba"
print(🙃)

var 🥶🥺 : [String] = ["valpo","talca","quillota"]


for 🤬 in 🥶🥺{
    print(🤬)
}


