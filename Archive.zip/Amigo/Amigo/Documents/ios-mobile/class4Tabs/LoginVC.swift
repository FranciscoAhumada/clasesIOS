//
//  LoginVC.swift
//  class4Tabs
//
//  Created by user162332 on 1/17/20.
//  Copyright © 2020 user164457. All rights reserved.
//

import UIKit
import TextFieldFloatingPlaceholder
import Alamofire

class LoginVC: UIViewController {
    
    @IBOutlet var Usuario: TextFieldFloatingPlaceholder!
    @IBOutlet var Contrasena: TextFieldFloatingPlaceholder!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Usuario.validation = { $0.count > 4 }
        Usuario.validationFalseLineColor = .lightGray
        Usuario.validationFalseLineEditingColor = .lightGray
        Usuario.validationTrueLineEditingColor = .green
        Contrasena.validation = { $0.count > 4 }
        Contrasena.validationFalseLineColor = .lightGray
        Contrasena.validationFalseLineEditingColor = .lightGray
        Contrasena.validationTrueLineEditingColor = .green
        
    
    }
    
    @IBAction func ingresar(_ sender: Any) {
        if let usu = self.Usuario.text, let pas = self.Contrasena.text {
            if usu.isEmpty || pas.isEmpty{
                let alert = UIAlertController(title: "alerta", message: "Campos vacios", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                DispatchQueue.main.async {
                    self.present(alert,animated: true, completion: nil)
                }
                return
            }
        }
        
        self.downloadDataFromAPI { (const) in
            if const{
                self.performSegue(withIdentifier: "Home", sender: self)
            }else{
                let alert = UIAlertController(title: "alerta", message: "Campos malos", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                DispatchQueue.main.async {
                    self.present(alert,animated: true, completion: nil)
                }
            }
        }
        
        
    }
    
    func downloadDataFromAPI(respuesta:@escaping(Bool)->Void){
       AF.request("http://www.mocky.io/v2/5e25b92c2f0000296cce2c72").responseJSON { response in
           
        
        let JSON = try! response.result.get()
        
        if let datos = JSON as? [String: AnyObject]{
            respuesta (datos["login"] as! Bool)

        }
     
          }
       
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


