//
//  BiometricService.swift
//  class4Tabs
//
//  Created by user162332 on 1/17/20.
//  Copyright © 2020 user164457. All rights reserved.
//

import UIKit
import LocalAuthentication

class BiometricService: NSObject {

    private static let _shared = BiometricService()
    static var shared:BiometricService{
        return _shared
    }
    
    private let context = LAContext()
    
    func access(text: String, completion:@escaping(Bool)->Void){
        self.context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        self.context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: text){(state:Bool, _ ) in
            DispatchQueue.main.async {
                completion(state)
            }
        }
        
    }
}
