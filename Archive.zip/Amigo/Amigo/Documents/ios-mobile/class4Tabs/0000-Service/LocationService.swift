//
//  LocationService.swift
//  class4Tabs
//
//  Created by user162332 on 1/17/20.
//  Copyright © 2020 user164457. All rights reserved.
//

import Foundation
import CoreLocation

class LocationService: NSObject {
    private static let _shared = LocationService()
    static var shared : LocationService{
        return _shared
    }
    
    let manager = CLLocationManager()
    
    func permisos(status: @escaping(Bool)->Void){
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse{
            status(true)
            self.manager.delegate = self
        }else{
            status(false)
        }
    }
}

extension LocationService: CLLocationManagerDelegate{
    
}
