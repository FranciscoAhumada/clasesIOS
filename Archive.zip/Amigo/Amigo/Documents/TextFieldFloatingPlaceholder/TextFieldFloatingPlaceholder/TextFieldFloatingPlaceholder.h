//
//  TextFieldFloatingPlaceholder.h
//  TextFieldFloatingPlaceholder
//
//  Created by 辻林 大揮 on 2018/04/13.
//  Copyright © 2018年 chocovayashi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TextFieldFloatingPlaceholder.
FOUNDATION_EXPORT double TextFieldFloatingPlaceholderVersionNumber;

//! Project version string for TextFieldFloatingPlaceholder.
FOUNDATION_EXPORT const unsigned char TextFieldFloatingPlaceholderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TextFieldFloatingPlaceholder/PublicHeader.h>


