//
//  ViewController.swift
//  Test
//
//  Created by user162332 on 1/13/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var saludoLabel: UILabel!
    
    @IBOutlet var botonCargar: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.saludoLabel.text = "wena mundo"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.botonCargar.addTarget(self, action: #selector(self.updateNAme), for: .touchUpInside)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("view did appear")
        //self.updateNAme()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("view will disappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("view did disappear")
    }

    
}

extension ViewController {
    @objc func updateNAme(){
        self.saludoLabel.text = "update"
    }
}

