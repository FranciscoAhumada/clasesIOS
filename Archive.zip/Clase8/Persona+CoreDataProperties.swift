//
//  Persona+CoreDataProperties.swift
//  Clase8
//
//  Created by user162332 on 1/22/20.
//  Copyright © 2020 Prueba. All rights reserved.
//
//

import Foundation
import CoreData


extension Persona {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Persona> {
        return NSFetchRequest<Persona>(entityName: "Persona")
    }

    @NSManaged public var imagenUsuario: Data?
    @NSManaged public var nombre: String?
    @NSManaged public var rut: String?
    @NSManaged public var tarjeta: NSSet?

}

// MARK: Generated accessors for tarjeta
extension Persona {

    @objc(addTarjetaObject:)
    @NSManaged public func addToTarjeta(_ value: Tarjeta)

    @objc(removeTarjetaObject:)
    @NSManaged public func removeFromTarjeta(_ value: Tarjeta)

    @objc(addTarjeta:)
    @NSManaged public func addToTarjeta(_ values: NSSet)

    @objc(removeTarjeta:)
    @NSManaged public func removeFromTarjeta(_ values: NSSet)

}
