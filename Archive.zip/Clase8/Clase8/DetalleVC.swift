//
//  DetalleVC.swift
//  CoreData
//
//  Created by user162332 on 1/21/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class DetalleVC: UIViewController {

    @IBOutlet var imagen: UIImageView!
    
    @IBOutlet var Label: [UILabel]!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.Label[0].text = "mi nombre"
        self.Label[1].text = "15.654.853-k"
        // Do any additional setup after loading the view.
    }

}

extension DetalleVC: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "personCell", for: indexPath)
        return cell
    }
}
