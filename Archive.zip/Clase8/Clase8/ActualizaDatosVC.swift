//
//  ActualizaDatosVC.swift
//  Clase8
//
//  Created by user162332 on 1/22/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class ActualizaDatosVC: UIViewController {

    @IBOutlet var imagen: UIImageView!
    @IBOutlet var nombreA: UITextField!
    @IBOutlet var rutA: UITextField!
    @IBOutlet var saveButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.imagen.layer.borderColor = UIColor.blue.cgColor
        self.imagen.layer.borderWidth = 2.0
        self.imagen.layer.cornerRadius = self.imagen.frame.width/2
        
        self.nombreA.delegate = self
        self.rutA.delegate = self
        
    }

}


extension ActualizaDatosVC: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case self.nombreA:
            self.rutA.becomeFirstResponder()
        case self.rutA:
            self.view.endEditing(true)
        default:
            self.view.endEditing(true)
        }
        return true
    }
}
