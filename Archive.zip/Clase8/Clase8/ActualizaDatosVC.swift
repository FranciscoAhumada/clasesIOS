//
//  ActualizaDatosVC.swift
//  Clase8
//
//  Created by user162332 on 1/22/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit
import CoreData

class ActualizaDatosVC: UIViewController {

    @IBOutlet var imagen: UIImageView!
    @IBOutlet var nombreA: UITextField!
    @IBOutlet var rutA: UITextField!
    @IBOutlet var saveButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.imagen.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.imagenInteraction(_:)))
        self.imagen.addGestureRecognizer(tap)
        
        self.saveButton.addTarget(self, action: #selector(self.save), for: .touchUpInside)
        self.imagen.layer.borderColor = UIColor.blue.cgColor
        self.imagen.layer.borderWidth = 2.0
        self.imagen.layer.cornerRadius = self.imagen.frame.width/2
        
        self.nombreA.delegate = self
        self.rutA.delegate = self
        
    }

}


extension ActualizaDatosVC: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case self.nombreA:
            self.rutA.becomeFirstResponder()
        case self.rutA:
            self.view.endEditing(true)
        default:
            self.view.endEditing(true)
        }
        return true
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension ActualizaDatosVC{
    
    @objc func imagenInteraction(_ sender:UITapGestureRecognizer){
        if sender.numberOfTouchesRequired == 1{
            print("un tab")
        }else if sender.numberOfTouchesRequired == 2{
            print("dos tab")
        }
        
    }
    
    @objc func save(){
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let 👤 = NSManagedObject(entity: NSEntityDescription.entity(forEntityName: "Persona", in: context)!, insertInto: context)
        
        👤.setValue(self.nombreA.text, forKey: "nombre")
        👤.setValue(self.rutA.text, forKey: "rut")
        
        do{
            try context.save()
            self.performSegue(withIdentifier: "backToHome", sender: self)
            print("guardo")
        }catch let errorSave as NSError{
            print("No guardo", errorSave)
        }
    }
}
