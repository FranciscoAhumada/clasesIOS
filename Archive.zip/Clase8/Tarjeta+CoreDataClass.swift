//
//  Tarjeta+CoreDataClass.swift
//  Clase8
//
//  Created by user162332 on 1/22/20.
//  Copyright © 2020 Prueba. All rights reserved.
//
//

import Foundation
import CoreData


public class Tarjeta: NSManagedObject {

}
