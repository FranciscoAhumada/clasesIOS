//
//  detalleOpercionTV.swift
//  multipantallas
//
//  Created by user162332 on 1/15/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class detalleOpercionTV: UITableViewCell {

    @IBOutlet var fotoPerfilImage: UIImageView!
    @IBOutlet var nombreLabel: UILabel!
    @IBOutlet var paisLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
