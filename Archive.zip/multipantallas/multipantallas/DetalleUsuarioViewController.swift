//
//  DetalleUsuarioViewController.swift
//  multipantallas
//
//  Created by user162332 on 1/14/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class DetalleUsuarioViewController: UIViewController {
    var nombre : String?
    var datos : [String] = ["pedro", "juan"]
    var usuarios : [Persona] = []
    @IBOutlet var tableView: UITableView!
    @IBOutlet var nombreLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.nombreLabel.text = nombre
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.estimatedRowHeight = 100
        self.tableView.rowHeight = 100
        
        let usuario = Persona(nombre: "Francisco", rut: "18654853-9", pais: "Shile")
        let usuario2 = Persona(nombre: "bombom", rut: "8654853-9", pais: "Uruguay")
        let usuario3 = Persona(nombre: "MAtias", rut: "1854853-9", pais: "Argentina")
        
        self.usuarios.append(usuario)
        self.usuarios.append(usuario2)
        self.usuarios.append(usuario3)

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detalleUsuarioVC = segue.destination as? DetalleUsuarioVCCollectionViewController{
            if let index = self.tableView.indexPathForSelectedRow{
                detalleUsuarioVC.persona
            }
        }
    }

}

extension DetalleUsuarioViewController: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.usuarios.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! detalleOpercionTV
        cell.nombreLabel.text = self.usuarios[indexPath.row].nombre
        cell.paisLabel.text = self.usuarios[indexPath.row].pais
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.tableView.deselectRow(at: indexPath, animated: true)
        print(self.usuarios[indexPath.row])
    }
}
