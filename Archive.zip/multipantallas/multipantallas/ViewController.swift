//
//  ViewController.swift
//  multipantallas
//
//  Created by user162332 on 1/14/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet var nombreTextField: UITextField!
    @IBAction func segueByVode(_ sender: UIButton) {
        self.performSegue(withIdentifier: "detalle", sender: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.nombreTextField.delegate = self
        // Do any additional setup after loading the view.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        
        return true
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let transition = segue.destination as?
            DetalleUsuarioViewController{
            /*DispatchQueue.main.async {
                transition.nombreLabel.text = self.nombreTextField.text
            }*/
            if let nombre = self.nombreTextField.text{
                transition.nombre = nombre
            }
            
        }
    }

}

