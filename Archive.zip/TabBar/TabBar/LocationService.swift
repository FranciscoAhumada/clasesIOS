//
//  LocationService.swift
//  TabBar
//
//  Created by user162332 on 1/17/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class LocationService: NSObject {

}
