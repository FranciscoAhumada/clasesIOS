//
//  HomeVC.swift
//  TabBar
//
//  Created by user162332 on 1/16/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {
    
    let button = UIButton()

    @IBOutlet var cuboBlanco: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        button.shadow(shadowColorPorcent: 0.3)
        cuboBlanco.shadow(shadowColorPorcent: 0.3)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
