//
//  ViewController.swift
//  TabBar
//
//  Created by user162332 on 1/16/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

