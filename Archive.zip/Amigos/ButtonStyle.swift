//
//  Button.swift
//  Amigos
//
//  Created by user162332 on 1/23/20.
//  Copyright © 2020 Prueba. All rights reserved.
//

import SwiftUI

struct ButtonStyle: View {
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

extension ButtonStyle{
    private func printer(){
        print("cargando")
    }
}

struct ButtonStyle_Previews: PreviewProvider {
    static var previews: some View {
        ButtonStyle()
    }
}
