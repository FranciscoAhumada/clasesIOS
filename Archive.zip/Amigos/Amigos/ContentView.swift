//
//  ContentView.swift
//  FriendsApp
//
//  Created by user164457 on 1/23/20.
//  Copyright © 2020 user164457. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State private var 👥: [Amigos] = []
    @State private var nombreUsuario: String = ""
    
    private func loadFriends() {
        self.👥.append(Amigos(name: "yo", rut: "1215485", isPremium: true))
        self.👥.append(Amigos(name: "yo2", rut: "1215485", isPremium: true))
        self.👥.append(Amigos(name: "yo3", rut: "1215485", isPremium: true))
        self.👥.append(Amigos(name: "yo4", rut: "1215485", isPremium: true))
        self.👥.append(Amigos(name: "yo5", rut: "1215485", isPremium: true))
        
    }
    
    var body: some View {
        
        VStack{
            Form{
                Text("\(self.nombreUsuario)")
                VStack{
                    Text("Nombre")
                    TextField("Nombre", text: $nombreUsuario)
                }
            }
            List{
                ForEach(👥){ 👤 in
                    VStack{
                        Text(👤.name).bold()
                        Text(👤.rut)
                    }
                    
                }
            }
            Button(action:self.loadFriends) {
              Text("cargar amigos")
            }
        }
        
        /*Form{
            Text("\(self.nombreUsuario)")
            VStack{
                Text("Nombre")
                TextField("Nombre", text: $nombreUsuario)
            }
        }*/
        
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
