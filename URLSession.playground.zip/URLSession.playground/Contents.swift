import Foundation

let session = URLSession.shared

if let link = URL(string: "http://bip-servicio.herokuapp.com/api/v1/solicitudes.json?bip=\(83345448)"){
    let task = session.dataTask(with: link){
        (info:Data?, response : URLResponse?, error: Error?) in
        if let responseServer = response as?
            HTTPURLResponse, let data = info{
            do {
                let datos = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
                
                if let datosRespuesta = datos as? [String:AnyObject]{
                    print(datosRespuesta)
                }
            } catch  {
                print("fallo")
            }
        }
    }
    task.resume()
}
